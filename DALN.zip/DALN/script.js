// Chinh anh 
var imgFeature = document.querySelector('.img-feature')
var listImg = document.querySelectorAll('.list-image img')

listImg.forEach(imgElement=>{
    imgElement.addEventListener('click', e=>{
        imgFeature.src = e.target.getAttribute('src')
    })

})
// Đổi màu icon 

// Lay du lieu tu san pham 
 var giohang = new Array();
 
function cartAdd(x){
    var boxProduct = x.parentElement.children;
    var productImg = boxProduct[0].children[0].src
    var productName = boxProduct[1].children[1].innerText
    var productPrice = boxProduct[1].children[3].innerText
    var productQuantity = boxProduct[1].children[4].value
     var product = new Array(productImg,productName,productPrice,productQuantity);
    // giohang.push(product);
    // Loại bỏ trùng lặp 
    var index = -1;
    for (var i = 0; i < giohang.length; i++) {
        if (giohang[i][1] === productName) {
            index = i;
            break;
        }
    }
    if (index !== -1) {
        
        giohang[index][3] = parseInt(giohang[index][3]) + parseInt(productQuantity);
    } else {
       
        var product = [productImg, productName, productPrice, productQuantity];
        giohang.push(product);
    }
    console.log(giohang);
    //showcount ();
    addCount();

    // Lưu giỏ hàng lên SessionStorage
    sessionStorage.setItem("giohang",JSON.stringify(giohang));
    
   
}

// Hiển thị số sản phẩm trong giỏ
function addCount()
{
    document.querySelector(".cart-icon").innerHTML = giohang.length;
}


// Hiển thị giỏ hàng trên trang cart
function show_cartpage()
{
    var gh = sessionStorage.getItem("giohang");
    var giohang =JSON.parse(gh);
    var tong = 0;
    var infor = " "
    // Đọc dữ liệu trong mảng ra td và tr
    for(let i = 0; i < giohang.length; i++)
    {
        var sum = parseInt(giohang[i][2]) * parseInt(giohang[i][3]);
        tong += sum;
        infor += ' <tr>' +
        '<td>' + 
        ' <button class="b_delete" onclick="dlSp(this)"><i class="far fa-times-circle"></i></button>' +
        '</td>' +
        '<td><img src="'+giohang[i][0] +'" alt=""></td> ' +
        '<td>'+giohang[i][1] +'</td> ' +
        '<td>' + giohang[i][2] + '</td>' +
        '<td>' + giohang[i][3] + '</td> ' +
       // tong tien 
        ' <td>' + sum +'</td> ' + 
        '</tr>';
    }

        document.getElementById("mycart").innerHTML = infor;
        
    // Hiển thị tổng tiền mua   
     var total = document.getElementById("Total");
     if(total)
    {
        total.innerHTML =  tong;
    }
}

// Xóa sp 
function dlSp(x)
{
    // Xoá từ thẻ cha chứa nó 
    var sp = x.parentElement.parentElement;
    var spName = sp.children[2].innerText;
    sp.remove();

    // Xóa sp trong mảng chứa sp 
    for(let i = 0 ; i < giohang.length; i++)
    {
        // lay ten sp so sanh voi cai lay ve
        if(giohang[i][1] == spName)
        {
            giohang.splice(i,1); // lấy tại i và xóa 1 phần tử 
        }
    }
     var total = document.getElementById("Total");
     if (total) {
        total.innerHTML = tong;
    }
    // cập nhật dem so sp
    addCount();
    // Cập nhật giỏ hàng sau khi xóa 
    show_cartpage();
    
}
// Thanh toán tất cả 
function clearCart() {
   // xóa tất cả sp trong mảng 
    giohang = [];
    // cap nhat sessionStorage
    sessionStorage.setItem("giohang", JSON.stringify(giohang));
    // cập nhật khi xóa tất cả 
    var total = document.getElementById("Total");
    if (total) {
        total.innerHTML = 0;
    }
    // cập nhật dem so sp
    addCount();
    // Cập nhật giỏ hàng sau khi xóa 
    show_cartpage();
    alert('Thanh toán thành công');
}
/*-------------------------------------------------------------------------------*/








